from setuptools import setup, find_packages

setup(
    name="quantforex-pro",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "fastapi==0.111.0",
        "uvicorn[standard]==0.30.0",
        "pydantic==2.7.4",
        "pydantic-settings==2.3.4",
        "sqlalchemy==2.0.31",
        "alembic==1.13.2",
        "python-jose[cryptography]==3.3.0",
        "passlib[bcrypt]==1.7.4",
        "python-multipart==0.0.9",
        "httpx==0.27.0",
        "websockets==12.0",
        "pandas==2.2.2",
        "numpy==2.0.0",
        "python-dotenv==1.0.1",
        "asyncpg==0.29.0",
        "aiosqlite==0.20.0",
    ],
)
