"""Backtesting endpoints."""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import BacktestRequest, BacktestResponse, BacktestResult
from app.services.indicators import generate_signals
from app.services.backtest import generate_synthetic_data, run_backtest

router = APIRouter(prefix="/backtest", tags=["Backtesting"])

@router.post("/run", response_model=BacktestResponse)
async def run_backtest_endpoint(request: BacktestRequest, current_user: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    data = generate_synthetic_data(request.pair, request.candle_count)
    settings = {
        "pair": request.pair, "timeframe": request.timeframe,
        "strategies": {"rsi": request.strategies.rsi, "smc": request.strategies.smc, "sd": request.strategies.sd,
                       "crt": request.strategies.crt, "fundamental": request.strategies.fundamental},
        "weights": {"rsi": request.weights.rsi, "smc": request.weights.smc, "sd": request.weights.sd, "crt": request.weights.crt},
        "rsi_period": request.rsi_period, "rsi_overbought": request.rsi_overbought, "rsi_oversold": request.rsi_oversold,
        "risk_percent": request.risk_percent, "stop_loss_pips": request.stop_loss_pips,
        "take_profit_pips": request.take_profit_pips, "initial_capital": request.initial_capital
    }
    signals, confidences, breakdowns = generate_signals(data, settings)
    result = run_backtest(data, signals, confidences, breakdowns, settings)

    record = BacktestResult(user_id=current_user.get("user_id", 0), pair=request.pair, timeframe=request.timeframe,
                            strategies=settings["strategies"], total_return=result["metrics"]["total_return"],
                            win_rate=result["metrics"]["win_rate"], profit_factor=result["metrics"]["profit_factor"],
                            max_drawdown=result["metrics"]["max_drawdown"], total_trades=result["metrics"]["total_trades"],
                            sharpe_ratio=result["metrics"]["sharpe_ratio"], equity_curve=result["equity_curve"], trades=result["trades"])
    db.add(record)
    await db.commit()
    await db.refresh(record)

    return BacktestResponse(id=record.id, pair=request.pair, timeframe=request.timeframe, metrics=result["metrics"],
                            equity_curve=result["equity_curve"], trades=result["trades"], signals=result["signals"],
                            generated_at=record.created_at)

@router.get("/history")
async def get_history(current_user: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(BacktestResult).where(BacktestResult.user_id == current_user.get("user_id", 0)))
    backtests = result.scalars().all()
    return [{"id": b.id, "pair": b.pair, "timeframe": b.timeframe,
             "metrics": {"total_return": b.total_return, "win_rate": b.win_rate, "profit_factor": b.profit_factor,
                        "max_drawdown": b.max_drawdown, "total_trades": b.total_trades, "sharpe_ratio": b.sharpe_ratio},
             "created_at": b.created_at} for b in backtests]
