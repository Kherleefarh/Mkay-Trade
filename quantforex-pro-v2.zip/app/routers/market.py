"""Market data and WebSocket."""
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import List
import asyncio
from datetime import datetime
from app.services.indicators import generate_signals
from app.services.backtest import generate_synthetic_data
from app.models.models import SignalResponse

router = APIRouter(prefix="/market", tags=["Market Data"])
active_connections: List[WebSocket] = []

@router.get("/pairs")
async def get_pairs():
    return {"pairs": [
        {"symbol": "EURUSD", "name": "EUR/USD", "pip_value": 0.0001},
        {"symbol": "GBPUSD", "name": "GBP/USD", "pip_value": 0.0001},
        {"symbol": "USDJPY", "name": "USD/JPY", "pip_value": 0.01},
        {"symbol": "AUDUSD", "name": "AUD/USD", "pip_value": 0.0001},
        {"symbol": "USDCAD", "name": "USD/CAD", "pip_value": 0.0001},
        {"symbol": "XAUUSD", "name": "XAU/USD (Gold)", "pip_value": 0.01}
    ]}

@router.get("/data/{pair}")
async def get_data(pair: str, candles: int = 200):
    data = generate_synthetic_data(pair, candles)
    return {"pair": pair, "candles": [{"date": d["date"].isoformat(), "open": d["open"], "high": d["high"],
                                       "low": d["low"], "close": d["close"], "volume": d["volume"]} for d in data]}

@router.post("/signal/{pair}")
async def get_signal(pair: str, settings: dict = None):
    data = generate_synthetic_data(pair, 100)
    default = {"pair": pair, "strategies": {"rsi": True, "smc": True, "sd": True, "crt": False, "fundamental": False},
               "weights": {"rsi": 0.25, "smc": 0.30, "sd": 0.25, "crt": 0.20},
               "rsi_period": 14, "rsi_overbought": 70, "rsi_oversold": 30}
    if settings: default.update(settings)
    signals, confidences, breakdowns = generate_signals(data, default)
    last = len(data) - 1
    return SignalResponse(signal=signals[last], confidence=confidences[last], breakdown=breakdowns[last],
                          timestamp=datetime.now(), price=data[last]["close"])

@router.websocket("/ws/{pair}")
async def websocket_stream(websocket: WebSocket, pair: str):
    await websocket.accept()
    active_connections.append(websocket)
    try:
        while True:
            data = generate_synthetic_data(pair, 50)
            last = data[-1]
            settings = {"pair": pair, "strategies": {"rsi": True, "smc": True, "sd": True, "crt": False, "fundamental": False},
                        "weights": {"rsi": 0.25, "smc": 0.30, "sd": 0.25, "crt": 0.20},
                        "rsi_period": 14, "rsi_overbought": 70, "rsi_oversold": 30}
            signals, confidences, breakdowns = generate_signals(data, settings)
            await websocket.send_json({"type": "tick", "pair": pair, "price": last["close"],
                                        "timestamp": datetime.now().isoformat(), "signal": signals[-1],
                                        "confidence": confidences[-1], "breakdown": breakdowns[-1],
                                        "candle": {"open": last["open"], "high": last["high"], "low": last["low"], "close": last["close"], "volume": last["volume"]}})
            await asyncio.sleep(2)
    except WebSocketDisconnect:
        if websocket in active_connections: active_connections.remove(websocket)
    except Exception:
        if websocket in active_connections: active_connections.remove(websocket)
