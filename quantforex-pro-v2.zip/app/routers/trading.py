"""Live trading endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import TradeEntry, TradeLog
from app.services.broker import broker

router = APIRouter(prefix="/trading", tags=["Live Trading"])

@router.get("/account")
async def get_account(current_user: dict = Depends(get_current_user)):
    return await broker.get_account()

@router.get("/positions")
async def get_positions(current_user: dict = Depends(get_current_user)):
    return await broker.get_positions()

@router.post("/order")
async def place_order(order: TradeEntry, current_user: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    if not broker.api_key: raise HTTPException(status_code=400, detail="OANDA API not configured")
    instrument = order.pair.replace("/", "_")
    units = int(abs(order.entry_price))
    if order.direction == "SHORT": units = -units
    result = await broker.place_order(instrument, units, order.stop_loss, order.take_profit)
    trade = TradeLog(user_id=current_user.get("user_id", 0), pair=order.pair, direction=order.direction,
                     entry_price=order.entry_price, strategies=order.strategies, is_live=True,
                     broker_order_id=result.get("orderFill", {}).get("id") if "orderFill" in result else None)
    db.add(trade)
    await db.commit()
    return {"broker_response": result, "trade_id": trade.id, "status": "submitted"}

@router.get("/history")
async def get_history(current_user: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(TradeLog).where(TradeLog.user_id == current_user.get("user_id", 0)))
    trades = result.scalars().all()
    return [{"id": t.id, "pair": t.pair, "direction": t.direction, "entry_price": t.entry_price,
             "exit_price": t.exit_price, "pips": t.pips, "pnl": t.pnl, "status": t.status,
             "strategies": t.strategies, "is_live": t.is_live, "created_at": t.created_at, "closed_at": t.closed_at}
            for t in trades]

@router.post("/close/{trade_id}")
async def close_trade(trade_id: int, current_user: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(TradeLog).where(TradeLog.id == trade_id, TradeLog.user_id == current_user.get("user_id", 0)))
    trade = result.scalar_one_or_none()
    if not trade: raise HTTPException(status_code=404, detail="Trade not found")
    if trade.status != "OPEN": raise HTTPException(status_code=400, detail="Trade not open")
    if trade.is_live and broker.api_key:
        await broker.close_position(trade.pair.replace("/", "_"))
    trade.status = "CLOSED"
    trade.closed_at = datetime.now()
    await db.commit()
    return {"status": "closed", "trade_id": trade_id}
