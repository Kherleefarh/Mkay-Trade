"""Backtesting engine."""
import numpy as np
from typing import List, Dict, Any
from datetime import datetime
from app.services.indicators import generate_signals


def generate_synthetic_data(pair: str, count: int = 500):
    base_prices = {
        "EURUSD": 1.0800, "GBPUSD": 1.2600, "USDJPY": 150.00,
        "AUDUSD": 0.6500, "USDCAD": 1.3500, "XAUUSD": 2050.00
    }
    base = base_prices.get(pair, 1.0800)
    volatility = 8.0 if pair == "XAUUSD" else (0.15 if pair == "USDJPY" else 0.0015)
    data = []
    price = base
    now = datetime.now()
    np.random.seed(42)

    for i in range(count, -1, -1):
        trend = np.sin(i / 50) * volatility * 2
        noise = (np.random.random() - 0.5) * volatility
        change = trend + noise
        open_p = price
        close_p = price + change
        high_p = max(open_p, close_p) + np.random.random() * volatility * 0.5
        low_p = min(open_p, close_p) - np.random.random() * volatility * 0.5
        volume = int(10000 + np.random.random() * 40000)
        date = datetime.fromtimestamp(now.timestamp() - i * 3600 * 4)
        data.append({
            "date": date, "open": round(open_p, 5), "high": round(high_p, 5),
            "low": round(low_p, 5), "close": round(close_p, 5), "volume": volume
        })
        price = close_p
    return data


def run_backtest(data, signals, confidences, breakdowns, settings):
    trades = []
    equity_curve = [settings.get("initial_capital", 10000)]
    capital = settings.get("initial_capital", 10000)
    peak = capital
    max_drawdown = 0.0

    pair = settings.get("pair", "EURUSD")
    pip_size = 0.01 if pair in ["USDJPY", "XAUUSD"] else 0.0001
    stop_pips = settings.get("stop_loss_pips", 25)
    tp_pips = settings.get("take_profit_pips", 50)
    risk_pct = settings.get("risk_percent", 2.0)

    for i in range(len(data)):
        if signals[i] == "HOLD" or confidences[i] < 0.6:
            equity_curve.append(capital)
            continue

        direction = signals[i]
        entry = data[i]["close"]
        risk_amount = capital * (risk_pct / 100)
        win_prob = 0.45 + (confidences[i] * 0.3)
        is_win = np.random.random() < win_prob
        pips = tp_pips if is_win else -stop_pips
        pip_value = 10.0
        position_size = risk_amount / (stop_pips * pip_value)
        pnl = pips * pip_value * position_size
        capital += pnl
        if capital > peak: peak = capital
        drawdown = (peak - capital) / peak
        if drawdown > max_drawdown: max_drawdown = drawdown

        exit_price = entry + (pips * pip_size) if direction == "LONG" else entry - (pips * pip_size)
        trades.append({
            "index": i, "date": data[i]["date"].isoformat(), "direction": direction,
            "entry": round(entry, 5), "exit": round(exit_price, 5), "pips": pips,
            "pnl": round(pnl, 2), "capital": round(capital, 2),
            "confidence": confidences[i], "breakdown": breakdowns[i],
            "result": "WIN" if is_win else "LOSS"
        })
        equity_curve.append(capital)

    wins = [t for t in trades if t["result"] == "WIN"]
    losses = [t for t in trades if t["result"] == "LOSS"]
    total_return = ((equity_curve[-1] - settings.get("initial_capital", 10000)) / settings.get("initial_capital", 10000)) * 100
    win_rate = (len(wins) / len(trades) * 100) if trades else 0
    profit_factor = (sum(t["pnl"] for t in wins) / abs(sum(t["pnl"] for t in losses))) if losses else float("inf")

    returns = []
    for i in range(1, len(equity_curve)):
        returns.append((equity_curve[i] - equity_curve[i-1]) / equity_curve[i-1])
    avg_return = np.mean(returns) if returns else 0
    std_dev = np.std(returns) if returns else 0
    sharpe = (avg_return / std_dev * np.sqrt(252)) if std_dev > 0 else 0

    return {
        "metrics": {
            "total_return": round(total_return, 2), "win_rate": round(win_rate, 2),
            "profit_factor": round(profit_factor, 2), "max_drawdown": round(max_drawdown * 100, 2),
            "total_trades": len(trades), "sharpe_ratio": round(sharpe, 2)
        },
        "equity_curve": [round(e, 2) for e in equity_curve],
        "trades": trades,
        "signals": [{"index": i, "signal": signals[i], "confidence": confidences[i], "breakdown": breakdowns[i]}
                    for i in range(len(signals)) if signals[i] != "HOLD"]
    }
