"""Technical indicator calculations."""
import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional


def calculate_rsi(closes: List[float], period: int = 14):
    closes = np.array(closes)
    deltas = np.diff(closes)
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    avg_gains = pd.Series(gains).rolling(window=period).mean().values
    avg_losses = pd.Series(losses).rolling(window=period).mean().values
    rs = np.where(avg_losses == 0, 100, avg_gains / avg_losses)
    rsi = 100 - (100 / (1 + rs))
    rsi = np.concatenate([[50.0] * period, rsi[period:]])

    n = len(closes)
    bull_div = [False] * n
    bear_div = [False] * n
    for i in range(5, n):
        if closes[i] < closes[i-5] and rsi[i] > rsi[i-5]:
            bull_div[i] = True
        if closes[i] > closes[i-5] and rsi[i] < rsi[i-5]:
            bear_div[i] = True
    return rsi.tolist(), bull_div, bear_div


def calculate_smc(highs, lows, closes):
    n = len(closes)
    structure = ["neutral"] * n
    fvg = [None] * n
    for i in range(5, n):
        recent_highs = highs[max(0, i-5):i]
        recent_lows = lows[max(0, i-5):i]
        if recent_highs and highs[i] > max(recent_highs):
            structure[i] = "bullish_bos"
        elif recent_lows and lows[i] < min(recent_lows):
            structure[i] = "bearish_bos"
        if i >= 3:
            if highs[i-2] < lows[i-1] and closes[i] > highs[i-1]:
                fvg[i] = "bullish_fvg"
            elif lows[i-2] > highs[i-1] and closes[i] < lows[i-1]:
                fvg[i] = "bearish_fvg"
    return structure, fvg


def calculate_supply_demand(data, lookback=20):
    n = len(data)
    demand_zones = [False] * n
    supply_zones = [False] * n
    for i in range(lookback, n):
        window = data[max(0, i-lookback):i]
        min_low = min(d["low"] for d in window)
        max_high = max(d["high"] for d in window)
        prev = data[i-1]
        curr = data[i]
        if prev["low"] == min_low and curr["close"] > curr["open"]:
            demand_zones[i] = True
        if prev["high"] == max_high and curr["close"] < curr["open"]:
            supply_zones[i] = True
    return demand_zones, supply_zones


def calculate_crt(highs, lows, opens, closes):
    n = len(closes)
    pin_bar_high = [False] * n
    pin_bar_low = [False] * n
    for i in range(1, n):
        body = abs(closes[i] - opens[i])
        upper_wick = highs[i] - max(closes[i], opens[i])
        lower_wick = min(closes[i], opens[i]) - lows[i]
        if upper_wick > body * 2 and closes[i] < opens[i]:
            pin_bar_high[i] = True
        if lower_wick > body * 2 and closes[i] > opens[i]:
            pin_bar_low[i] = True
    return pin_bar_high, pin_bar_low


def find_swing_levels(highs, lows, lookback=20):
    swing_highs, swing_lows = [], []
    for i in range(lookback, len(highs) - lookback):
        wh = highs[max(0, i-lookback):i+lookback+1]
        wl = lows[max(0, i-lookback):i+lookback+1]
        if highs[i] == max(wh):
            swing_highs.append({"index": i, "price": highs[i]})
        if lows[i] == min(wl):
            swing_lows.append({"index": i, "price": lows[i]})
    return swing_highs, swing_lows


def generate_signals(data, settings):
    n = len(data)
    closes = [d["close"] for d in data]
    highs = [d["high"] for d in data]
    lows = [d["low"] for d in data]
    opens = [d["open"] for d in data]

    signals = ["HOLD"] * n
    confidences = [0.0] * n
    breakdowns = [{} for _ in range(n)]

    rsi_values, rsi_bull, rsi_bear = calculate_rsi(closes, settings.get("rsi_period", 14))
    smc_structure, smc_fvg = calculate_smc(highs, lows, closes)
    sd_demand, sd_supply = calculate_supply_demand(data)
    crt_high, crt_low = calculate_crt(highs, lows, opens, closes)
    swing_highs, swing_lows = find_swing_levels(highs, lows)

    strategies = settings.get("strategies", {})
    weights = settings.get("weights", {})

    for i in range(50, n):
        long_score, short_score = 0.0, 0.0
        bd = {}

        if strategies.get("rsi", True):
            if rsi_values[i] < settings.get("rsi_oversold", 30) and rsi_bull[i]:
                long_score += weights.get("rsi", 0.25); bd["rsi"] = "LONG"
            elif rsi_values[i] > settings.get("rsi_overbought", 70) and rsi_bear[i]:
                short_score += weights.get("rsi", 0.25); bd["rsi"] = "SHORT"
            else: bd["rsi"] = "HOLD"

        if strategies.get("smc", True):
            if smc_structure[i] == "bullish_bos" and smc_fvg[i] == "bullish_fvg":
                long_score += weights.get("smc", 0.30); bd["smc"] = "LONG"
            elif smc_structure[i] == "bearish_bos" and smc_fvg[i] == "bearish_fvg":
                short_score += weights.get("smc", 0.30); bd["smc"] = "SHORT"
            else: bd["smc"] = "HOLD"

        if strategies.get("sd", True):
            recent_demand = any(sd_demand[max(0, i-5):i+1])
            recent_supply = any(sd_supply[max(0, i-5):i+1])
            if recent_demand: long_score += weights.get("sd", 0.25); bd["sd"] = "LONG"
            elif recent_supply: short_score += weights.get("sd", 0.25); bd["sd"] = "SHORT"
            else: bd["sd"] = "HOLD"

        if strategies.get("crt", False):
            recent_high = any(abs(i - sh["index"]) < 5 for sh in swing_highs[-5:])
            recent_low = any(abs(i - sl["index"]) < 5 for sl in swing_lows[-5:])
            if crt_high[i] and recent_high: short_score += weights.get("crt", 0.20); bd["crt"] = "SHORT"
            elif crt_low[i] and recent_low: long_score += weights.get("crt", 0.20); bd["crt"] = "LONG"
            else: bd["crt"] = "HOLD"

        if strategies.get("fundamental", False):
            fund_score = (np.random.random() - 0.5) * 2
            if fund_score > 0.3: long_score *= 1.2
            elif fund_score < -0.3: short_score *= 1.2
            bd["fundamental"] = round(fund_score, 2)

        threshold = 0.5
        if long_score > threshold and long_score > short_score:
            signals[i] = "LONG"; confidences[i] = round(long_score, 3)
        elif short_score > threshold and short_score > long_score:
            signals[i] = "SHORT"; confidences[i] = round(short_score, 3)

        breakdowns[i] = bd

    return signals, confidences, breakdowns
