"""OANDA broker integration."""
import httpx
from typing import Optional, Dict, Any
from app.core.config import get_settings

settings = get_settings()
BASE_URLS = {"practice": "https://api-fxpractice.oanda.com/v3", "live": "https://api-fxtrade.oanda.com/v3"}

class OANDABroker:
    def __init__(self, api_key=None, account_id=None, environment=None):
        self.api_key = api_key or settings.OANDA_API_KEY
        self.account_id = account_id or settings.OANDA_ACCOUNT_ID
        self.environment = environment or settings.OANDA_ENVIRONMENT
        self.base_url = BASE_URLS.get(self.environment, BASE_URLS["practice"])
        self.headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

    async def get_account(self):
        if not self.api_key: return {"error": "OANDA API key not configured"}
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{self.base_url}/accounts/{self.account_id}/summary", headers=self.headers)
            return resp.json()

    async def get_prices(self, instruments):
        if not self.api_key: return {"error": "OANDA API key not configured"}
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{self.base_url}/accounts/{self.account_id}/pricing", headers=self.headers, params={"instruments": instruments})
            return resp.json()

    async def place_order(self, instrument, units, stop_loss=None, take_profit=None):
        if not self.api_key: return {"error": "OANDA API key not configured"}
        order = {"order": {"type": "MARKET", "instrument": instrument, "units": str(units), "timeInForce": "FOK", "positionFill": "DEFAULT"}}
        if stop_loss: order["order"]["stopLossOnFill"] = {"price": str(stop_loss)}
        if take_profit: order["order"]["takeProfitOnFill"] = {"price": str(take_profit)}
        async with httpx.AsyncClient() as client:
            resp = await client.post(f"{self.base_url}/accounts/{self.account_id}/orders", headers=self.headers, json=order)
            return resp.json()

    async def get_positions(self):
        if not self.api_key: return {"error": "OANDA API key not configured"}
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{self.base_url}/accounts/{self.account_id}/openPositions", headers=self.headers)
            return resp.json()

    async def close_position(self, instrument, units=None):
        if not self.api_key: return {"error": "OANDA API key not configured"}
        params = {}
        if units: params["units"] = str(units)
        async with httpx.AsyncClient() as client:
            resp = await client.put(f"{self.base_url}/accounts/{self.account_id}/positions/{instrument}/close", headers=self.headers, params=params)
            return resp.json()

broker = OANDABroker()
