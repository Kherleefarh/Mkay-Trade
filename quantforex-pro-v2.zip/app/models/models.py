"""ORM models and Pydantic schemas."""
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text, JSON
from sqlalchemy.sql import func
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from app.core.database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class BacktestResult(Base):
    __tablename__ = "backtest_results"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)
    pair = Column(String(20), nullable=False)
    timeframe = Column(String(10), nullable=False)
    strategies = Column(JSON)
    total_return = Column(Float)
    win_rate = Column(Float)
    profit_factor = Column(Float)
    max_drawdown = Column(Float)
    total_trades = Column(Integer)
    sharpe_ratio = Column(Float)
    equity_curve = Column(JSON)
    trades = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class TradeLog(Base):
    __tablename__ = "trade_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)
    pair = Column(String(20), nullable=False)
    direction = Column(String(10), nullable=False)
    entry_price = Column(Float, nullable=False)
    exit_price = Column(Float)
    pips = Column(Float)
    pnl = Column(Float)
    status = Column(String(20), default="OPEN")
    strategies = Column(JSON)
    is_live = Column(Boolean, default=False)
    broker_order_id = Column(String(100))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    closed_at = Column(DateTime(timezone=True))

class UserCreate(BaseModel):
    email: str
    password: str
    full_name: Optional[str] = None

class UserLogin(BaseModel):
    email: str
    password: str

class UserResponse(BaseModel):
    id: int
    email: str
    full_name: Optional[str]
    created_at: datetime
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class StrategyConfig(BaseModel):
    rsi: bool = True
    smc: bool = True
    sd: bool = True
    crt: bool = False
    fundamental: bool = False

class StrategyWeights(BaseModel):
    rsi: float = Field(0.25, ge=0, le=1)
    smc: float = Field(0.30, ge=0, le=1)
    sd: float = Field(0.25, ge=0, le=1)
    crt: float = Field(0.20, ge=0, le=1)

class BacktestRequest(BaseModel):
    pair: str = Field(..., pattern=r"^[A-Z]{6}$|^[A-Z]{3}/[A-Z]{3}$")
    timeframe: str = Field("4h", pattern=r"^(1m|5m|15m|1h|4h|1d|1w)$")
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    strategies: StrategyConfig = StrategyConfig()
    weights: StrategyWeights = StrategyWeights()
    rsi_period: int = Field(14, ge=2, le=50)
    rsi_overbought: int = Field(70, ge=50, le=95)
    rsi_oversold: int = Field(30, ge=5, le=50)
    risk_percent: float = Field(2.0, ge=0.1, le=10.0)
    stop_loss_pips: int = Field(25, ge=5, le=200)
    take_profit_pips: int = Field(50, ge=10, le=500)
    initial_capital: float = Field(10000.0, ge=1000)
    candle_count: int = Field(500, ge=100, le=5000)

class TradeEntry(BaseModel):
    pair: str
    direction: str = Field(..., pattern=r"^(LONG|SHORT)$")
    entry_price: float
    stop_loss: float
    take_profit: float
    risk_percent: float = Field(2.0, ge=0.1, le=10.0)
    strategies: List[str] = []
    notes: Optional[str] = None

class SignalResponse(BaseModel):
    signal: str
    confidence: float
    breakdown: Dict[str, Any]
    timestamp: datetime
    price: float

class BacktestMetrics(BaseModel):
    total_return: float
    win_rate: float
    profit_factor: float
    max_drawdown: float
    total_trades: int
    sharpe_ratio: float

class BacktestResponse(BaseModel):
    id: Optional[int]
    pair: str
    timeframe: str
    metrics: BacktestMetrics
    equity_curve: List[float]
    trades: List[Dict[str, Any]]
    signals: List[Dict[str, Any]]
    generated_at: datetime
